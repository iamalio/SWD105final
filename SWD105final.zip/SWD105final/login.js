const express = require('express');
const login = express();
const handlebars = require('express-handlebars');
const sqlite3 = require("sqlite3").verbose();
const Sequelize = require("Sequelize");
const passport = require("passport");
const FacebookStrategy = require("passport-facebook").Strategy;



const sequelize = new Sequelize("Music", "michael", null, {
    host: "localhost",
    dialect: "sqlite",
    storage: "./swd105data.db"
  });

  const User = sequelize.define(
    "User",
    {
      userId: {
        type: Sequelize.STRING,
        autoIncrement: true,
        primaryKey: true
      },
      authId: type: Sequelize.STRING,
      name: Sequelize.STRING,
      email: Sequelize.STRING,
      role: Sequelize.STRING
    },
    {
      freezeTableName: true
    }
  );

  export default login;