import login from './login';

const express = require('express');
const app = express();
const handlebars = require('express-handlebars');
const sqlite3 = require("sqlite3").verbose();
const Sequelize = require("Sequelize");
app.use((require("body-parser")()));

routes.post('/newPost', (req, res) => {
    console.log("Name: " + req.body.name);
    console.log("Let me say that: " + req.body.mywords);
    res.redirect(303, './newPost');
})

const db = new sqlite3.Database("./swd105data.db");

routes.engine('handlebars', handlebars({ defaultLayout: 'main'}));
routes.set('view engine', 'handlebars');

routes.set("port", process.env.PORT || 3000);

routes.get('/newPost', (request, response) => {
    response.render('/newPost');
});

app.listen(3000, () => {
    console.log('IMposter started on port 3000, press Ctrl+C to terminate.' );
  });